#include <stdio.h>

void main(){
      printf("Hello World!");
      sleep(10);
      return 0;
}
